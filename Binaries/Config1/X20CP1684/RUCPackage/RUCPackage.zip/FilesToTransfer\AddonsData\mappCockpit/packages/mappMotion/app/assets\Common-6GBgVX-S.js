const t="140px";export{t as D};
