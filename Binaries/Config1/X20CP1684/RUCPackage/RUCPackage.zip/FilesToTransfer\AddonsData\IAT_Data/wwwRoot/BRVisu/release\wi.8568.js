"use strict";(self.webpackChunkwidgets=self.webpackChunkwidgets||[]).push([[8568],{38568:a=>{a.exports=`\uFEFF<div id="breaseKeyBoard" data-brease-widget="widgets/brease/KeyBoard" data-lang="zh">\r
\r
    <header class="keyBoardHeader">\r
        <div></div>\r
    </header>\r
\r
    <div class="keyBoardBody">\r
        <div class="keyBoardTop">\r
            <div class="keyBoardInputField">\r
                <input type="text" readonly="readonly" />\r
                <button class="keyBoardBtnClear">&times;</button>\r
            </div>\r
            <div class="keyBoardPlugin">\r
            </div>\r
        </div>\r
        <div class="keyBoardButtons">\r
            <div class="keyBoardRow">\r
                <button data-value="\`" data-shift-value="~" data-special-value="~"></button>\r
                <button data-value="1" data-shift-value="!" data-special-value="!"></button>\r
                <button data-value="2" data-shift-value="@" data-special-value="\xB2"></button>\r
                <button data-value="3" data-shift-value="#" data-special-value="\xB3"></button>\r
                <button data-value="4" data-shift-value="$" data-special-value="$"></button>\r
                <button data-value="5" data-shift-value="%" data-special-value="%"></button>\r
                <button data-value="6" data-shift-value="^" data-special-value="^"></button>\r
                <button data-value="7" data-shift-value="&" data-special-value="&"></button>\r
                <button data-value="8" data-shift-value="*" data-special-value="*"></button>\r
                <button data-value="9" data-shift-value="(" data-special-value="("></button>\r
                <button data-value="0" data-shift-value=")" data-special-value=")"></button>\r
                <button data-value="=" data-shift-value="+" data-special-value="\u5143"></button>\r
                <button data-value="\\" data-shift-value="|" data-special-value="|"></button>\r
                <button class="delete" data-action="delete"><i class="icon-delete">&times;</i></button>\r
            </div>\r
            <div class="keyBoardRow margin1">\r
                <button data-value="\u624B" data-shift-value="Q" data-special-value="q"></button>\r
                <button data-value="\u7530" data-shift-value="W" data-special-value="w"></button>\r
                <button data-value="\u6C34" data-shift-value="E" data-special-value="e"></button>\r
                <button data-value="\u53E3" data-shift-value="R" data-special-value="r"></button>\r
                <button data-value="\u5EFF" data-shift-value="T" data-special-value="t"></button>\r
                <button data-value="\u535C" data-shift-value="Y" data-special-value="y"></button>\r
                <button data-value="\u5C71" data-shift-value="U" data-special-value="u"></button>\r
                <button data-value="\u6208" data-shift-value="I" data-special-value="i"></button>\r
                <button data-value="\u4EBA" data-shift-value="O" data-special-value="o"></button>\r
                <button data-value="\u5FC3" data-shift-value="P" data-special-value="p"></button>\r
                <button data-value="[" data-shift-value="{" data-special-value="{"></button>\r
                <button data-value="]" data-shift-value="}" data-special-value="}"></button>\r
                <button class="enter" data-action="enter">Enter</button>\r
            </div>\r
            <div class="keyBoardRow margin2">\r
                <button data-value="\u65E5" data-shift-value="A" data-special-value="a"></button>\r
                <button data-value="\u5C38" data-shift-value="S" data-special-value="s"></button>\r
                <button data-value="\u6728" data-shift-value="D" data-special-value="d"></button>\r
                <button data-value="\u706B" data-shift-value="F" data-special-value="f"></button>\r
                <button data-value="\u571F" data-shift-value="G" data-special-value="g"></button>\r
                <button data-value="\u7AF9" data-shift-value="H" data-special-value="h"></button>\r
                <button data-value="\u5341" data-shift-value="J" data-special-value="j"></button>\r
                <button data-value="\u5927" data-shift-value="K" data-special-value="k"></button>\r
                <button data-value="\u4E2D" data-shift-value="L" data-special-value="l"></button>\r
                <button data-value=";" data-shift-value=":" data-special-value=":"></button>\r
                <button data-value="'" data-shift-value="&quot;" data-special-value="&quot;"></button>\r
                <button data-value="/" data-shift-value="?" data-special-value="?"></button>\r
                <button class="moveLeft" data-action="left"><i class="icon-left"></i></button>\r
                <button class="moveRight" data-action="right"><i class="icon-right"></i></button>\r
\r
            </div>\r
            <div class="keyBoardRow">\r
                <button class="shift-left wide" data-action="shift"><i class="icon-shift"></i></button>\r
                <button data-value="\u91CD" data-shift-value="Z" data-special-value="z"></button>\r
                <button data-value="\u96E3" data-shift-value="X" data-special-value="x"></button>\r
                <button data-value="\u91D1" data-shift-value="C" data-special-value="c"></button>\r
                <button data-value="\u5973" data-shift-value="V" data-special-value="v"></button>\r
                <button data-value="\u6708" data-shift-value="B" data-special-value="b"></button>\r
                <button data-value="\u5F13" data-shift-value="N" data-special-value="n"></button>\r
                <button data-value="\u4E00" data-shift-value="M" data-special-value="m"></button>\r
                <button data-value="," data-shift-value="&lt;" data-special-value="&lt;"></button>\r
                <button data-value="." data-shift-value="&gt;" data-special-value="&gt;"></button>\r
                <button data-value="-" data-shift-value="_" data-special-value="\xA5"></button>\r
                <button class="shift-right wide" data-action="shift"><i class="icon-shift"></i></button>\r
\r
            </div>\r
            <div class="keyBoardRow">\r
				<div class="btnCloseSm alt-lt-Wrapper"></div>\r
                <button class="specialChars" data-action="special">abc</button>\r
                <button class="space" data-value="&nbsp;" data-shift-value="&nbsp;" data-special-value="&nbsp;"></button>\r
                <button class="btnCloseSm" data-action="close"><i class="icon-down"></i></button>\r
            </div>\r
        </div>\r
\r
    </div>\r
</div>\r
`}}]);
