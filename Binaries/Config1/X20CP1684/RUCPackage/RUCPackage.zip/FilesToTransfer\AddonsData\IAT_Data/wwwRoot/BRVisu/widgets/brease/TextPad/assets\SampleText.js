define({
    program: 'Lorem ipsum dolor sit amet, consectetur adipiscing \n' +
        'elit, sed eiusmod tempor incidunt ut labore et \n' +
        'dolore magna aliqua. Ut enim ad minim veniam, \n' +
        'quis nostrud exercitation ullamco laboris nisi ut \n' +
        'aliquid ex ea commodi consequat.  Quis aute iure \n' +
        'reprehenderit in voluptate velit esse cillum dolore \n' +
        'eu fugiat nulla pariatur. Excepteur sint obcaecat \n' +
        'cupiditat non proident,  sunt in culpa qui  \n' +
        'officia deserunt mollit anim id est laborum.'
});
