"use strict";(self.webpackChunkwidgets=self.webpackChunkwidgets||[]).push([[9164],{59164:t=>{t.exports=`<div id="breaseTextKeyPad" class="breaseTextKeyPad hidden" data-brease-widget="widgets/brease/TextKeyPad" style="height:auto;z-index:0;" data-lang="zh">\r
    <div>\r
        <div class="row">\r
            <button data-action="prevCandidates" class="invisible">-</button>\r
            <button data-action="insertCharacter" class="doubleWidth invisible suggestion"><span></span><sup></sup><sub></sub></button>\r
            <button data-action="insertCharacter" class="doubleWidth invisible suggestion"><span></span><sup></sup><sub></sub></button>\r
            <button data-action="insertCharacter" class="doubleWidth invisible suggestion"><span></span><sup></sup><sub></sub></button>\r
            <button data-action="insertCharacter" class="doubleWidth invisible suggestion"><span></span><sup></sup><sub></sub></button>\r
            <button data-action="insertCharacter" class="doubleWidth invisible suggestion"><span></span><sup></sup><sub></sub></button>\r
            <button data-action="insertCharacter" class="doubleWidth invisible suggestion"><span></span><sup></sup><sub></sub></button>\r
            <button data-action="insertCharacter" class="doubleWidth invisible suggestion"><span></span><sup></sup><sub></sub></button>\r
            <button data-action="nextCandidates" class="invisible">+</button>\r
        </div>\r
        <div class="row">\r
            <button data-action="insertCharacter" class="cornerAlign"><span>~</span><sup></sup><sub>\`</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>!</span><sup></sup><sub>1</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>@</span><sup>\xB2</sup><sub>2</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>#</span><sup>\xB3</sup><sub>3</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>$</span><sup></sup><sub>4</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>%</span><sup></sup><sub>5</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>^</span><sup></sup><sub>6</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>&amp;</span><sup></sup><sub>7</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>*</span><sup></sup><sub>8</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>(</span><sup></sup><sub>9</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>)</span><sup></sup><sub>0</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>+</span><sup>\u5143</sup><sub>=</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>|</span><sup></sup><sub>\\</sub></button>\r
            <button data-key="Backspace" data-action="backspace" data-ctrl-action="removewordleft" data-alt-action="removetolinestart" class="doubleWidth"><span>Bksp</span><sub></sub><sup></sup></button>\r
            <button data-key="Close" data-action="close"><span></span><sub></sub><sup></sup></button>\r
        </div>\r
        <div class="row">\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="Tab" data-action="indent" data-shift-action="outdent" class="doubleWidth"><span>Tab</span><sub></sub><sup></sup></button>\r
                    <button data-action="insertCharacter"><span>Q</span><sup>q</sup><sub>\u624B</sub></button>\r
                    <button data-action="insertCharacter"><span>W</span><sup>w</sup><sub>\u7530</sub></button>\r
                    <button data-action="insertCharacter"><span>E</span><sup>e</sup><sub>\u6C34</sub></button>\r
                    <button data-action="insertCharacter"><span>R</span><sup>r</sup><sub>\u53E3</sub></button>\r
                    <button data-action="insertCharacter"><span>T</span><sup>t</sup><sub>\u5EFF</sub></button>\r
                    <button data-key="Y" data-action="insertCharacter" data-ctrl-action="redo"><span>Y</span><sup>y</sup><sub>\u535C</sub></button>\r
                    <button data-key="U" data-action="insertCharacter" data-ctrl-action="touppercase" data-ctrl-shift-action="tolowercase"><span>U</span><sup>u</sup><sub>\u5C71</sub></button>\r
                    <button data-action="insertCharacter"><span>I</span><sup>i</sup><sub>\u6208</sub></button>\r
                    <button data-action="insertCharacter"><span>O</span><sup>o</sup><sub>\u4EBA</sub></button>\r
                    <button data-key="P" data-action="insertCharacter" data-ctrl-action="jumptomatching"><span>P</span><sup>p</sup><sub>\u5FC3</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>{</span><sup></sup><sub>[</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>}</span><sup></sup><sub>]</sub></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="Caps" data-action="capslock" class="doubleWidth">Caps<sub></sub><sup></sup></button>\r
                    <button data-key="A" data-action="insertCharacter" data-ctrl-action="selectall"><span>A</span><sup>a</sup><sub>\u65E5</sub></button>\r
                    <button data-action="insertCharacter"><span>S</span><sup>s</sup><sub>\u5C38</sub></button>\r
                    <button data-key="D" data-action="insertCharacter" data-ctrl-action="removeline" data-ctrl-shift-action="duplicateSelection"><span>D</span><sup>d</sup><sub>\u6728</sub></button>\r
                    <button data-key="F" data-action="insertCharacter" data-ctrl-action="find" data-ctrl-shift-action="findprevious"><span>F</span><sup>f</sup><sub>\u706B</sub></button>\r
                    <button data-action="insertCharacter"><span>G</span><sup>g</sup><sub>\u571F</sub></button>\r
                    <button data-key="H" data-action="insertCharacter" data-ctrl-action="replace"><span>H</span><sup>h</sup><sub>\u7AF9</sub></button>\r
                    <button data-action="insertCharacter"><span>J</span><sup>j</sup><sub>\u5341</sub></button>\r
                    <button data-key="K" data-action="insertCharacter" data-ctrl-action="findnext" data-ctrl-shift-action="findprevious"><span>K</span><sup>k</sup><sub>\u5927</sub></button>\r
                    <button data-action="insertCharacter"><span>L</span><sup>l</sup><sub>\u4E2D</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>:</span><sup></sup><sub>;</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>&quot;</span><sup></sup><sub>'</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>?</span><sup></sup><sub>/</sub></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <button data-key="Enter" data-action="enter"><span>&crarr;</span><sub></sub><sup></sup></button>\r
            </div>\r
            <div class="col">\r
                <div class="row"><button data-key="Home" data-action="gotolinestart" data-ctrl-action="gotostart"><span>Home</span><sup></sup><sub></sub></button></div>\r
                <div class="row"><button data-key="End" data-action="gotolineend" data-ctrl-action="gotoend"><span>End</span><sup></sup><sub></sub></button></div>\r
            </div>\r
        </div>\r
        <div class="row">\r
            <div class="col">\r
                <button data-key="Shift" data-action="shift" class="doubleWidth"><span>Shift</span><sub></sub><sup></sup></button>\r
                <button data-key="Ctrl" data-action="ctrl" class="doubleWidth"><span>Ctrl</span><sub></sub><sup></sup></button>\r
            </div>\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="Z" data-action="insertCharacter" data-ctrl-action="undo"><span>Z</span><sup>z</sup><sub>\u91CD</sub></button>\r
                    <button data-key="X" data-action="insertCharacter" data-ctrl-action="vCut"><span>X</span><sup>x</sup><sub>\u96E3</sub></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="Alt" data-action="alt" class="doubleWidth"><span>Alt</span><sub></sub><sup></sup></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="C" data-action="insertCharacter" data-ctrl-action="vCopy"><span>C</span><sup>c</sup><sub>\u91D1</sub></button>\r
                    <button data-key="V" data-action="insertCharacter" data-ctrl-action="vPaste"><span>V</span><sup>v</sup><sub>\u5973</sub></button>\r
                    <button data-action="insertCharacter"><span>B</span><sup>b</sup><sub>\u6708</sub></button>\r
                    <button data-action="insertCharacter"><span>N</span><sup>n</sup><sub>\u5F13</sub></button>\r
                    <button data-action="insertCharacter"><span>M</span><sup>m</sup><sub>\u4E00</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>&lt;</span><sup></sup><sub>,</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>&gt;</span><sup></sup><sub>.</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>_</span><sup>\xA5</sup><sub>-</sub></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="switchLayout" data-action="switchLayout" class="doubleWidth"><span>zh</span><sup></sup><sub></sub></button>\r
                    <button data-key="Space" data-action="space" class="quadrupleWidth"><span>____</span><sup></sup><sub></sub></button>\r
                    <button data-key="AltGr" data-action="altgr" class="doubleWidth altgr"><span>Alt Gr</span><sup></sup><sub></sub></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="PageUp" data-action="gotopageup" data-shift-action="selectpageup" class="cornerAlign"><span>&uarr;</span><sub></sub><sup>pg</sup></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="Left" data-action="gotoleft" data-shift-action="selectleft" data-ctrl-shift-action="selectwordleft" data-alt-shift-action="selecttolinestart"><span>&larr;</span><sub></sub><sup></sup></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <button data-key="Up" data-action="golineup" data-shift-action="selectup" data-ctrl-action="scrollup" data-alt-action="movelinesup" data-alt-shift-action="copylinesup"><span>&uarr;</span><sub></sub><sup></sup></button>\r
                <button data-key="Down" data-action="golinedown" data-shift-action="selectdown" data-ctrl-action="scrolldown" data-alt-action="movelinesdown" data-alt-shift-action="copylinesdown"><span>&darr;</span><sub></sub><sup></sup></button>\r
            </div>\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="PageDown" data-action="gotopagedown" data-shift-action="selectpagedown" class="cornerAlign"><span>&darr;</span><sub></sub><sup>pg</sup></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="Right" data-action="gotoright" data-shift-action="selectright" data-ctrl-shift-action="selectwordright" data-alt-shift-action="selecttolineend"><span>&rarr;</span><sub></sub><sup></sup></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <div class="row"><button data-key="Ins" data-action="overwrite"><span>Ins</span><sup></sup><sub></sub></button></div>\r
                <div class="row"><button data-key="Del" data-action="del" data-ctrl-action="removewordright" data-alt-action="removetolineend"><span>Del</span><sup></sup><sub></sub></button></div>\r
            </div>\r
        </div>\r
    </div>\r
</div>`}}]);
