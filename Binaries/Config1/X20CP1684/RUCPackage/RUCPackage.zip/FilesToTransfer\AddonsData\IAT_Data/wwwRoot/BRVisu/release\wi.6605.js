"use strict";(self.webpackChunkwidgets=self.webpackChunkwidgets||[]).push([[6605],{56605:a=>{a.exports=`<div id="breaseKeyBoard" data-brease-widget="widgets/brease/KeyBoard" data-lang="bg">\r
\r
    <header class="keyBoardHeader">\r
        <div></div>\r
    </header>\r
\r
    <div class="keyBoardBody">\r
        <div class="keyBoardTop">\r
            <div class="keyBoardInputField">\r
                <input type="text" readonly="readonly" />\r
                <button class="keyBoardBtnClear">&times;</button>\r
            </div>\r
            <div class="keyBoardPlugin">\r
            </div>\r
        </div>\r
        <div class="keyBoardButtons">\r
            <div class="keyBoardRow">\r
                <button data-value="\`" data-shift-value="~" data-special-value=""></button>\r
                <button data-value="1" data-shift-value="!" data-special-value=""></button>\r
                <button data-value="2" data-shift-value="?" data-special-value=""></button>\r
                <button data-value="3" data-shift-value="+" data-special-value=""></button>\r
                <button data-value="4" data-shift-value="&quot;" data-special-value=""></button>\r
                <button data-value="5" data-shift-value="%" data-special-value=""></button>\r
                <button data-value="6" data-shift-value="=" data-special-value=""></button>\r
                <button data-value="7" data-shift-value=":" data-special-value=""></button>\r
                <button data-value="8" data-shift-value="/" data-special-value=""></button>\r
                <button data-value="9" data-shift-value="_" data-special-value=""></button>\r
                <button data-value="0" data-shift-value="\u2116" data-special-value=""></button>\r
                <button data-value="-" data-shift-value="\u0406" data-special-value=""></button>\r
                <button data-value="." data-shift-value="V" data-special-value=""></button>\r
                <button class="delete" data-action="delete"><i class="icon-delete">&times;</i></button>\r
            </div>\r
            <div class="keyBoardRow margin1">\r
                <button data-value="," data-shift-value="\u044B" data-special-value=""></button>\r
                <button data-value="\u0443" data-shift-value="\u0423" data-special-value=""></button>\r
                <button data-value="e" data-shift-value="\u0415" data-special-value=""></button>\r
                <button data-value="\u0438" data-shift-value="\u0418" data-special-value=""></button>\r
                <button data-value="\u0448" data-shift-value="\u0428" data-special-value=""></button>\r
                <button data-value="\u0449" data-shift-value="\u0429" data-special-value=""></button>\r
                <button data-value="\u043A" data-shift-value="\u041A" data-special-value=""></button>\r
                <button data-value="\u0441" data-shift-value="\u0421" data-special-value=""></button>\r
                <button data-value="\u0434" data-shift-value="\u0414" data-special-value=""></button>\r
                <button data-value="\u0437" data-shift-value="\u0417" data-special-value=""></button>\r
                <button data-value="\u0446" data-shift-value="\u0426" data-special-value=""></button>\r
                <button data-value=";" data-shift-value="\xA7" data-special-value=""></button>\r
                <button class="enter" data-action="enter">&#x21b2;</button>\r
            </div>\r
            <div class="keyBoardRow margin2">\r
                <button data-value="\u044C" data-shift-value="\u042C" data-special-value=""></button>\r
                <button data-value="\u044F" data-shift-value="\u042F" data-special-value=""></button>\r
                <button data-value="\u0430" data-shift-value="\u0410" data-special-value=""></button>\r
                <button data-value="\u043E" data-shift-value="\u041E" data-special-value=""></button>\r
                <button data-value="\u0436" data-shift-value="\u0416" data-special-value=""></button>\r
                <button data-value="\u0433" data-shift-value="\u0413" data-special-value=""></button>\r
                <button data-value="\u0442" data-shift-value="\u0422" data-special-value=""></button>\r
                <button data-value="\u043D" data-shift-value="\u041D" data-special-value=""></button>\r
                <button data-value="\u0432" data-shift-value="\u0412" data-special-value=""></button>\r
                <button data-value="\u043C" data-shift-value="\u041C" data-special-value=""></button>\r
                <button data-value="\u0447" data-shift-value="\u0427" data-special-value=""></button>\r
                <button data-value="(" data-shift-value=")" data-special-value=""></button>\r
                <button class="moveLeft" data-action="left"><i class="icon-left"></i></button>\r
                <button class="moveRight" data-action="right"><i class="icon-right"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
                <button class="shift-left" data-action="shift"><i class="icon-shift"></i></button>\r
                <button data-value="\u044E" data-shift-value="" data-special-value="\u044E"></button>\r
                <button data-value="\u0439" data-shift-value="Z" data-special-value=""></button>\r
                <button data-value="\u044A" data-shift-value="X" data-special-value=""></button>\r
                <button data-value="\u044D" data-shift-value="C" data-special-value=""></button>\r
                <button data-value="\u0444" data-shift-value="V" data-special-value=""></button>\r
                <button data-value="\u0445" data-shift-value="B" data-special-value=""></button>\r
                <button data-value="\u043F" data-shift-value="N" data-special-value=""></button>\r
                <button data-value="\u0440" data-shift-value="M" data-special-value=""></button>\r
                <button data-value="\u043B" data-shift-value="&lt;" data-special-value=""></button>\r
                <button data-value="\u0431" data-shift-value="&gt;" data-special-value=""></button>\r
                <button data-value="&lt;" data-shift-value="&gt;" data-special-value=""></button>\r
                <button class="shift-right" data-action="shift"><i class="icon-shift"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
			    <div class="btnCloseSm alt-lt-Wrapper"></div>\r
                <button class="specialChars" data-action="special">&#*</button>\r
                <button class="space" data-value="&nbsp;" data-shift-value="&nbsp;" data-special-value="&nbsp;"></button>\r
                <button class="btnCloseSm" data-action="close"><i class="icon-down"></i></button>\r
            </div>\r
        </div>\r
    </div>\r
</div>\r
`}}]);
