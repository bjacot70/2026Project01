"use strict";(self.webpackChunkwidgets=self.webpackChunkwidgets||[]).push([[3351],{93351:a=>{a.exports=`<div id="breaseKeyBoard" data-brease-widget="widgets/brease/KeyBoard" data-lang="koen">\r
\r
    <header class="keyBoardHeader">\r
        <div></div>\r
    </header>\r
\r
    <div class="keyBoardBody">\r
        <div class="keyBoardTop">\r
            <div class="keyBoardInputField">\r
                <input type="text" readonly="readonly" />\r
                <button class="keyBoardBtnClear">&times;</button>\r
            </div>\r
            <div class="keyBoardPlugin">\r
            </div>\r
        </div>\r
        <div class="keyBoardButtons">\r
            <div class="keyBoardRow">\r
                <button data-value="\`" data-shift-value="~" data-special-value=""></button>\r
                <button data-value="1" data-shift-value="!" data-special-value="\xB0"></button>\r
                <button data-value="2" data-shift-value="@" data-special-value="\xB2"></button>\r
                <button data-value="3" data-shift-value="#" data-special-value="\xB3"></button>\r
                <button data-value="4" data-shift-value="$" data-special-value="\xA4"></button>\r
                <button data-value="5" data-shift-value="%" data-special-value="?"></button>\r
                <button data-value="6" data-shift-value="^" data-special-value="\xDF"></button>\r
                <button data-value="7" data-shift-value="&" data-special-value="{"></button>\r
                <button data-value="8" data-shift-value="*" data-special-value="["></button>\r
                <button data-value="9" data-shift-value="(" data-special-value="]"></button>\r
                <button data-value="0" data-shift-value=")" data-special-value="}"></button>\r
                <button data-value="-" data-shift-value="_" data-special-value="\xA5"></button>\r
                <button data-value="=" data-shift-value="+" data-special-value="\xD7"></button>\r
                <button class="delete" data-action="delete"><i class="icon-delete">&times;</i></button>\r
            </div>\r
            <div class="keyBoardRow margin1">\r
                <button data-value="q" data-shift-value="Q" data-special-value="\xE4"></button>\r
                <button data-value="w" data-shift-value="W" data-special-value="\xE5"></button>\r
                <button data-value="e" data-shift-value="E" data-special-value="\xE9"></button>\r
                <button data-value="r" data-shift-value="R" data-special-value="\xAE"></button>\r
                <button data-value="t" data-shift-value="T" data-special-value="\xFE"></button>\r
                <button data-value="y" data-shift-value="Y" data-special-value="\xFC"></button>\r
                <button data-value="u" data-shift-value="U" data-special-value="\xFA"></button>\r
                <button data-value="i" data-shift-value="I" data-special-value="\xED"></button>\r
                <button data-value="o" data-shift-value="O" data-special-value="\xF3"></button>\r
                <button data-value="p" data-shift-value="P" data-special-value="\xF6"></button>\r
                <button data-value="[" data-shift-value="{" data-special-value="\xAB"></button>\r
                <button data-value="]" data-shift-value="}" data-special-value="\xBB"></button>\r
                <button class="enter" data-action="enter">Enter</button>\r
            </div>\r
            <div class="keyBoardRow margin2">\r
                <button data-value="a" data-shift-value="A" data-special-value="\xE1"></button>\r
                <button data-value="s" data-shift-value="S" data-special-value="\xDF"></button>\r
                <button data-value="d" data-shift-value="D" data-special-value="\xF0"></button>\r
                <button data-value="f" data-shift-value="F" data-special-value=""></button>\r
                <button data-value="g" data-shift-value="G" data-special-value=""></button>\r
                <button data-value="h" data-shift-value="H" data-special-value=""></button>\r
                <button data-value="j" data-shift-value="J" data-special-value=""></button>\r
                <button data-value="k" data-shift-value="K" data-special-value=""></button>\r
                <button data-value="l" data-shift-value="L" data-special-value="\xF8"></button>\r
                <button data-value=";" data-shift-value=":" data-special-value="\xB6"></button>\r
                <button data-value="'" data-shift-value="&quot;" data-special-value="\xB4"></button>\r
                <button data-value="\\" data-shift-value="|" data-special-value="\xAC"></button>\r
                <button class="moveLeft" data-action="left"><i class="icon-left"></i></button>\r
                <button class="moveRight" data-action="right"><i class="icon-right"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
                <button class="shift-left wide" data-action="shift"><i class="icon-shift"></i></button>\r
                <button data-value="z" data-shift-value="Z" data-special-value="\xE6"></button>\r
                <button data-value="x" data-shift-value="X" data-special-value=""></button>\r
                <button data-value="c" data-shift-value="C" data-special-value="\xA9"></button>\r
                <button data-value="v" data-shift-value="V" data-special-value=""></button>\r
                <button data-value="b" data-shift-value="B" data-special-value=""></button>\r
                <button data-value="n" data-shift-value="N" data-special-value="\xF1"></button>\r
                <button data-value="m" data-shift-value="M" data-special-value="\xB5"></button>\r
                <button data-value="," data-shift-value="&lt;" data-special-value="\xE7"></button>\r
                <button data-value="." data-shift-value="&gt;" data-special-value=""></button>\r
                <button data-value="/" data-shift-value="?" data-special-value="\xBF"></button>\r
                <button class="shift-right wide" data-action="shift"><i class="icon-shift"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
                <div class="btnCloseSm alt-lt-Wrapper"></div>\r
                <button class="specialChars" data-action="special">&#*</button>\r
                <button class="space" data-value="&nbsp;" data-shift-value="&nbsp;" data-special-value="&nbsp;"></button>\r
                <button class="btnCloseSm" data-action="close"><i class="icon-down"></i></button>\r
            </div>\r
        </div>\r
    </div>\r
</div>\r
`}}]);
