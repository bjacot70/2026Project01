"use strict";(self.webpackChunkwidgets=self.webpackChunkwidgets||[]).push([[1080],{81080:a=>{a.exports=`<div id="breaseKeyBoard" data-brease-widget="widgets/brease/KeyBoard" data-lang="ko">\r
\r
    <header class="keyBoardHeader">\r
        <div></div>\r
    </header>\r
\r
    <div class="keyBoardBody">\r
        <div class="keyBoardTop">\r
            <div class="keyBoardInputField">\r
                <input type="text" readonly="readonly" />\r
                <button class="keyBoardBtnClear">&times;</button>\r
            </div>\r
            <div class="keyBoardPlugin">\r
            </div>\r
        </div>\r
        <div class="keyBoardButtons">\r
            <div class="keyBoardRow">\r
                <button data-value="1" data-shift-value="!" data-special-value="\xB0"></button>\r
                <button data-value="2" data-shift-value="&quot;" data-special-value="\xB2"></button>\r
                <button data-value="3" data-shift-value="\xA7" data-special-value="\xB3"></button>\r
                <button data-value="4" data-shift-value="$" data-special-value="$"></button>\r
                <button data-value="5" data-shift-value="%" data-special-value="%"></button>\r
                <button data-value="6" data-shift-value="&" data-special-value="&"></button>\r
                <button data-value="7" data-shift-value="/" data-special-value="{"></button>\r
                <button data-value="8" data-shift-value="(" data-special-value="["></button>\r
                <button data-value="9" data-shift-value=")" data-special-value="]"></button>\r
                <button data-value="0" data-shift-value="=" data-special-value="}"></button>\r
                <button class="delete" data-action="delete"><i class="icon-delete">&times;</i></button>\r
            </div>\r
            <div class="keyBoardRow margin1">\r
                <button data-value="\u3142" data-shift-value="\u3143" data-special-value="@"></button>\r
                <button data-value="\u3148" data-shift-value="\u3149" data-special-value="\xE4"></button>\r
                <button data-value="\u3137" data-shift-value="\u3138" data-special-value="\xC4"></button>\r
                <button data-value="\u3131" data-shift-value="\u3132" data-special-value="\xFC"></button>\r
                <button data-value="\u3145" data-shift-value="\u3146" data-special-value="\xDC"></button>\r
                <button data-value="\u315B" ></button>\r
                <button data-value="\u3155" ></button>\r
                <button data-value="\u3151" data-special-value="\xDF"></button>\r
                <button data-value="\u3150" data-shift-value="\u3152" data-special-value="&copy;"></button>\r
                <button data-value="\u3154" data-shift-value="\u3156" data-special-value="&reg;"></button>\r
                <button class="enter" data-action="enter">&#x21b2;</button>\r
            </div>\r
            <div class="keyBoardRow margin2">\r
                <button data-value="\u3141"  data-special-value="\xB5"></button>\r
                <button data-value="\u3134" data-special-value="\u03B1"></button>\r
                <button data-value="\u3147" data-special-value="\u03B2"></button>\r
                <button data-value="\u3139" data-special-value="\u03B3"></button>\r
                <button data-value="\u314E" data-special-value="/"></button>\r
                <button data-value="\u3157" data-special-value="*"></button>\r
                <button data-value="\u3153" data-special-value="="></button>\r
                <button data-value="\u314F" data-special-value="+"></button>\r
                <button data-value="\u3163" data-special-value="-"></button>\r
                <button class="moveLeft" data-action="left"><i class="icon-left"></i></button>\r
                <button class="moveRight" data-action="right"><i class="icon-right"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
                <button class="shift-left" data-action="shift"><i class="icon-shift"></i></button>\r
                <button data-value="\u314B" data-special-value="&lt;"></button>\r
                <button data-value="\u314C" data-special-value="&gt;"></button>\r
                <button data-value="\u314A" data-special-value="&laquo;"></button>\r
                <button data-value="\u314D" data-special-value="&raquo;"></button>\r
                <button data-value="\u3160" data-special-value="_"></button>\r
                <button data-value="\u315C" data-special-value="~"></button>\r
                <button data-value="\u3161" data-special-value="#"></button>\r
                <button data-value="," data-shift-value=";" data-special-value=";"></button>\r
                <button data-value="." data-shift-value=":" data-special-value=":"></button>\r
                <button class="shift-right" data-action="shift"><i class="icon-shift"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
			    <div class="btnCloseSm alt-lt-Wrapper"></div>\r
                <button class="specialChars" data-action="special">&#*</button>\r
                <button class="space" data-value="&nbsp;" data-shift-value="&nbsp;" data-special-value="&nbsp;"></button>\r
                <button class="btnCloseSm" data-action="close"><i class="icon-down"></i></button>\r
            </div>\r
        </div>\r
    </div>\r
</div>\r
`}}]);
