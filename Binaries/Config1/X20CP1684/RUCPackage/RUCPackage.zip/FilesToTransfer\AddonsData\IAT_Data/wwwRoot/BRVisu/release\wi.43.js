"use strict";(self.webpackChunkwidgets=self.webpackChunkwidgets||[]).push([[43],{60043:a=>{a.exports=`<div id="breaseKeyBoard" data-brease-widget="widgets/brease/KeyBoard" data-lang="sr">\r
\r
    <header class="keyBoardHeader">\r
        <div></div>\r
    </header>\r
\r
    <div class="keyBoardBody">\r
        <div class="keyBoardTop">\r
            <div class="keyBoardInputField">\r
                <input type="text" readonly="readonly"/>\r
                <button class="keyBoardBtnClear">&times;</button>\r
            </div>\r
            <div class="keyBoardPlugin">\r
            </div>\r
        </div>\r
        <div class="keyBoardButtons">\r
            <div class="keyBoardRow">\r
                <button data-value="\u201A" data-shift-value="~" data-special-value=""></button>\r
                <button data-value="1" data-shift-value="!" data-special-value="~"></button>\r
                <button data-value="2" data-shift-value="&quot;" data-special-value="\u02C7"></button>\r
                <button data-value="3" data-shift-value="#" data-special-value="^"></button>\r
                <button data-value="4" data-shift-value="$" data-special-value="\u02D8"></button>\r
                <button data-value="5" data-shift-value="%" data-special-value="\xB0"></button>\r
                <button data-value="6" data-shift-value="&" data-special-value="\u02DB"></button>\r
                <button data-value="7" data-shift-value="/" data-special-value="\`"></button>\r
                <button data-value="8" data-shift-value="(" data-special-value="\u02D9"></button>\r
                <button data-value="9" data-shift-value=")" data-special-value="\xB4"></button>\r
                <button data-value="0" data-shift-value="=" data-special-value="\u02DD"></button>\r
                <button data-value="'" data-shift-value="?" data-special-value="\xA8"></button>\r
                <button data-value="+" data-shift-value="*" data-special-value="\xB8"></button>\r
                <button class="delete" data-action="delete"><i class="icon-delete">&times;</i></button>\r
            </div>\r
            <div class="keyBoardRow margin1">\r
                <button data-value="q" data-shift-value="Q" data-special-value="\\"></button>\r
                <button data-value="w" data-shift-value="W" data-special-value="|"></button>\r
                <button data-value="e" data-shift-value="E" data-special-value="\u20AC"></button>\r
                <button data-value="r" data-shift-value="R" data-special-value=""></button>\r
                <button data-value="t" data-shift-value="T" data-special-value=""></button>\r
                <button data-value="z" data-shift-value="Z" data-special-value=""></button>\r
                <button data-value="u" data-shift-value="U" data-special-value=""></button>\r
                <button data-value="i" data-shift-value="I" data-special-value=""></button>\r
                <button data-value="o" data-shift-value="O" data-special-value=""></button>\r
                <button data-value="p" data-shift-value="P" data-special-value=""></button>\r
                <button data-value="\u0161" data-shift-value="\u0160" data-special-value="\xF7"></button>\r
                <button data-value="\u0111" data-shift-value="\u0110" data-special-value="\xD7"></button>\r
                <button class="enter" data-action="enter">Enter</button>\r
            </div>\r
            <div class="keyBoardRow margin2">\r
                <button data-value="a" data-shift-value="A" data-special-value=""></button>\r
                <button data-value="s" data-shift-value="S" data-special-value=""></button>\r
                <button data-value="d" data-shift-value="D" data-special-value=""></button>\r
                <button data-value="f" data-shift-value="F" data-special-value="["></button>\r
                <button data-value="g" data-shift-value="G" data-special-value="]"></button>\r
                <button data-value="h" data-shift-value="H" data-special-value=""></button>\r
                <button data-value="j" data-shift-value="J" data-special-value=""></button>\r
                <button data-value="k" data-shift-value="K" data-special-value="\u0142"></button>\r
                <button data-value="l" data-shift-value="L" data-special-value="\u0141"></button>\r
                <button data-value="\u010D" data-shift-value="\u010C" data-special-value=""></button>\r
                <button data-value="\u0107" data-shift-value="\u0106" data-special-value="\xDF"></button>\r
                <button data-value="\u017E" data-shift-value="\u017D" data-special-value="\xA4"></button>\r
                <button class="moveLeft" data-action="left"><i class="icon-left"></i></button>\r
                <button class="moveRight" data-action="right"><i class="icon-right"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
                <button class="shift-left" data-action="shift"><i class="icon-shift"></i></button>\r
                <button data-value="y" data-shift-value="Y" data-special-value=""></button>\r
                <button data-value="x" data-shift-value="X" data-special-value=""></button>\r
                <button data-value="c" data-shift-value="C" data-special-value=""></button>\r
                <button data-value="v" data-shift-value="V" data-special-value="@"></button>\r
                <button data-value="b" data-shift-value="B" data-special-value="{"></button>\r
                <button data-value="n" data-shift-value="N" data-special-value="}"></button>\r
                <button data-value="m" data-shift-value="M" data-special-value="\xA7"></button>\r
                <button data-value="," data-shift-value=";" data-special-value="<"></button>\r
                <button data-value="." data-shift-value=":" data-special-value=">"></button>\r
                <button data-value="-" data-shift-value="_" data-special-value=""></button>\r
                <button class="shift-right" data-action="shift"><i class="icon-shift"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
                <button class="specialChars" data-action="special">&#*</button>\r
                <button class="space" data-value="&nbsp;" data-shift-value="&nbsp;" data-special-value="&nbsp;"></button>\r
                <button class="btnClose" data-action="close"><i class="icon-down"></i></button>\r
            </div>\r
        </div>\r
    </div>\r
</div>\r
`}}]);
