"use strict";(self.webpackChunkwidgets=self.webpackChunkwidgets||[]).push([[2245],{32245:a=>{a.exports=`<div id="breaseKeyBoard" data-brease-widget="widgets/brease/KeyBoard" data-lang="ar">\r
\r
    <header class="keyBoardHeader">\r
        <div></div>\r
    </header>\r
\r
    <div class="keyBoardBody">\r
        <div class="keyBoardTop">\r
            <div class="keyBoardInputField">\r
                <input type="text" dir="rtl" readonly="readonly" />\r
                <button class="keyBoardBtnClear">&times;</button>\r
            </div>\r
            <div class="keyBoardPlugin">\r
            </div>\r
        </div>\r
        <div class="keyBoardButtons">\r
            <div class="keyBoardRow">\r
                <button data-value="\u0630" data-shift-value="&nbsp;\u0651&nbsp;"></button>\r
                <button data-value="1" data-shift-value="!" data-special-value="\xB0"></button>\r
                <button data-value="2" data-shift-value="&quot;" data-special-value="\xB2"></button>\r
                <button data-value="3" data-shift-value="\xA7" data-special-value="\xB3"></button>\r
                <button data-value="4" data-shift-value="$" data-special-value="$"></button>\r
                <button data-value="5" data-shift-value="%" data-special-value="%"></button>\r
                <button data-value="6" data-shift-value="&" data-special-value="&"></button>\r
                <button data-value="7" data-shift-value="/" data-special-value="{"></button>\r
                <button data-value="8" data-shift-value="(" data-special-value="["></button>\r
                <button data-value="9" data-shift-value=")" data-special-value="]"></button>\r
                <button data-value="0" data-shift-value="=" data-special-value="}"></button>\r
                <button class="delete" data-action="delete"><i class="icon-delete">&times;</i></button>\r
            </div>\r
            <div class="keyBoardRow margin1">\r
                <button data-value="\u0636" data-shift-value="&nbsp;\u064E&nbsp;" data-special-value="@"></button>\r
                <button data-value="\u0635" data-shift-value="&nbsp;\u064B&nbsp;"></button>\r
                <button data-value="\u062B" data-shift-value="&nbsp;\u064F&nbsp;"></button>\r
                <button data-value="\u0642" data-shift-value="&nbsp;\u064C&nbsp;"></button>\r
                <button data-value="\u0641" data-shift-value="\u0644"></button>\r
                <button data-value="\u063A" data-shift-value="\u0625"></button>\r
                <button data-value="\u0639" data-shift-value="\u2018"></button>\r
                <button data-value="\u0647" data-shift-value="\xF7"></button>\r
                <button data-value="\u062E" data-shift-value="\xD7" data-special-value="&copy;"></button>\r
                <button data-value="\u062D" data-shift-value="\u061B" data-special-value="&reg;"></button>\r
                <button data-value="\u062C" data-shift-value="&gt;"></button>\r
                <button data-value="\u062F" data-shift-value="&lt;"></button>\r
                <button class="enter" data-action="enter">&crarr;</button>\r
            </div>\r
            <div class="keyBoardRow margin2">\r
                <button data-value="\u0634" data-shift-value="&nbsp;\u0650&nbsp;" data-special-value="\xB5"></button>\r
                <button data-value="\u0633" data-shift-value="&nbsp;\u064D&nbsp;" data-special-value="\u03B1"></button>\r
                <button data-value="\u064A" data-shift-value="]" data-special-value="\u03B2"></button>\r
                <button data-value="\u0628" data-shift-value="[" data-special-value="\u03B3"></button>\r
                <button data-value="\u0644" data-shift-value="\u0644" data-special-value="/"></button>\r
                <button data-value="\u0627" data-shift-value="\u0623" data-special-value="*"></button>\r
                <button data-value="\u062A" data-shift-value="\u0640" data-special-value="="></button>\r
                <button data-value="\u0646" data-shift-value="\u060C" data-special-value="+"></button>\r
                <button data-value="\u0645" data-shift-value="/" data-special-value="-"></button>\r
                <button data-value="\u0643" data-shift-value=":" data-special-value=""></button>\r
                <button data-value="\u0637" data-shift-value="" data-special-value=""></button>\r
                <button class="moveLeft" data-action="left"><i class="icon-left"></i></button>\r
                <button class="moveRight" data-action="right"><i class="icon-right"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
                <button class="shift-left" data-action="shift"><i class="icon-shift"></i></button>\r
                <button data-value="\u0626" data-shift-value="~" data-special-value="&lt;"></button>\r
                <button data-value="\u0621" data-shift-value="&nbsp;\u0652&nbsp;" data-special-value="&gt;"></button>\r
                <button data-value="\u0624" data-shift-value="}" data-special-value="&laquo;"></button>\r
                <button data-value="\u0631" data-shift-value="{" data-special-value="&raquo;"></button>\r
                <button data-value="\u0644" data-shift-value="\u0644" data-special-value="_"></button>\r
                <button data-value="\u0649" data-shift-value="\u0622" data-special-value="~"></button>\r
                <button data-value="\u0629" data-shift-value="\u2019" data-special-value="#"></button>\r
                <button data-value="\u0648" data-shift-value="," data-special-value=";"></button>\r
                <button data-value="\u0632" data-shift-value="." data-special-value=""></button>\r
                <button data-value="\u0638" data-shift-value="\u061F" data-special-value=""></button>\r
                <button class="shift-right" data-action="shift"><i class="icon-shift"></i></button>\r
            </div>\r
            <div class="keyBoardRow">\r
			    <div class="btnCloseSm alt-lt-Wrapper"></div>\r
                <button class="specialChars" data-action="special">&#*</button>\r
                <button class="space" data-value="&nbsp;" data-shift-value="&nbsp;" data-special-value="&nbsp;"></button>\r
                <button class="btnCloseSm" data-action="close"><i class="icon-down"></i></button>\r
            </div>\r
        </div>\r
    </div>\r
</div>\r
`}}]);
