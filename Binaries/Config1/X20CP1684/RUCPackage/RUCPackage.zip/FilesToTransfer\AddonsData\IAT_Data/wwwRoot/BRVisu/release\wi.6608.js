"use strict";(self.webpackChunkwidgets=self.webpackChunkwidgets||[]).push([[6608],{46608:t=>{t.exports=`<div id="breaseTextKeyPad" class="breaseTextKeyPad hidden" data-brease-widget="widgets/brease/TextKeyPad" style="height:auto;z-index:0;" data-lang="ar">\r
    <div>\r
        <div class="row">\r
            <button data-action="insertCharacter" class="cornerAlign"><span>\xA0\u0651\xA0</span><sup></sup><sub>\u0630</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>!</span><sup>\xB0</sup><sub>1</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>&quot;</span><sup>\xB2</sup><sub>2</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>\xA7</span><sup>\xB3</sup><sub>3</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>$</span><sup></sup><sub>4</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>%</span><sup></sup><sub>5</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>&amp;</span><sup></sup><sub>6</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>/</span><sup>{</sup><sub>7</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>(</span><sup>[</sup><sub>8</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>)</span><sup>]</sup><sub>9</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>=</span><sup>}</sup><sub>0</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>_</span><sup></sup><sub>-</sub></button>\r
            <button data-action="insertCharacter" class="cornerAlign"><span>+</span><sup></sup><sub>=</sub></button>\r
            <button data-key="Backspace" data-action="backspace" data-ctrl-action="removewordleft" data-alt-action="removetolinestart" class="doubleWidth"><span>Bksp</span><sub></sub><sup></sup></button>\r
            <button data-key="Close" data-action="close"><span></span><sub></sub><sup></sup></button>\r
        </div>\r
        <div class="row">\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="Tab" data-action="indent" data-shift-action="outdent" class="doubleWidth"><span>Tab</span><sub></sub><sup></sup></button>\r
                    <button data-action="insertCharacter"><span>\xA0\u064E\xA0</span><sup>@</sup><sub>\u0636</sub></button>\r
                    <button data-action="insertCharacter"><span>\xA0\u064B\xA0</span><sup></sup><sub>\u0635</sub></button>\r
                    <button data-action="insertCharacter"><span>\xA0\u064F\xA0</span><sup></sup><sub>\u062B</sub></button>\r
                    <button data-action="insertCharacter"><span>\xA0\u064C\xA0</span><sup></sup><sub>\u0642</sub></button>\r
                    <button data-action="insertCharacter"><span>\u0644</span><sup></sup><sub>\u0641</sub></button>\r
                    <button data-key="Y" data-action="insertCharacter" data-ctrl-action="redo"><span>\u0625</span><sup></sup><sub>\u063A</sub></button>\r
                    <button data-key="U" data-action="insertCharacter" data-ctrl-action="touppercase" data-ctrl-shift-action="tolowercase"><span>\u2018</span><sup></sup><sub>\u0639</sub></button>\r
                    <button data-action="insertCharacter"><span>\xF7</span><sup></sup><sub>\u0647</sub></button>\r
                    <button data-action="insertCharacter"><span>\xD7</span><sup>\xA9</sup><sub>\u062E</sub></button>\r
                    <button data-key="P" data-action="insertCharacter" data-ctrl-action="jumptomatching"><span>\u061B</span><sup>\xAE</sup><sub>\u062D</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>&gt;</span><sup>\xAB</sup><sub>\u062C</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>&lt;</span><sup>\xBB</sup><sub>\u062F</sub></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="Caps" data-action="capslock" class="doubleWidth">Caps<sub></sub><sup></sup></button>\r
                    <button data-key="A" data-action="insertCharacter" data-ctrl-action="selectall"><span>\xA0\u0650\xA0</span><sup>\xB5</sup><sub>\u0634</sub></button>\r
                    <button data-action="insertCharacter"><span>\xA0\u064D\xA0</span><sup>\u03B1</sup><sub>\u0633</sub></button>\r
                    <button data-key="D" data-action="insertCharacter" data-ctrl-action="removeline" data-ctrl-shift-action="duplicateSelection"><span>]</span><sup>\u03B2</sup><sub>\u064A</sub></button>\r
                    <button data-key="F" data-action="insertCharacter" data-ctrl-action="find" data-ctrl-shift-action="findprevious"><span>[</span><sup>\u03B3</sup><sub>\u0628</sub></button>\r
                    <button data-action="insertCharacter"><span>\u0644</span><sup>/</sup><sub>\u0644</sub></button>\r
                    <button data-key="H" data-action="insertCharacter" data-ctrl-action="replace"><span>\u0623</span><sup>*</sup><sub>\u0627</sub></button>\r
                    <button data-action="insertCharacter"><span>\u0640</span><sup>=</sup><sub>\u062A</sub></button>\r
                    <button data-key="K" data-action="insertCharacter" data-ctrl-action="findnext" data-ctrl-shift-action="findprevious"><span>\u060C</span><sup>+</sup><sub>\u0646</sub></button>\r
                    <button data-action="insertCharacter"><span>/</span><sup>-</sup><sub>\u0645</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>:</span><sup></sup><sub>\u0643</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span></span><sup></sup><sub>\u0637</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>|</span><sup></sup><sub>\\</sub></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <button data-key="Enter" data-action="enter"><span>&crarr;</span><sub></sub><sup></sup></button>\r
            </div>\r
            <div class="col">\r
                <div class="row"><button data-key="Home" data-action="gotolinestart" data-ctrl-action="gotostart"><span>Home</span><sup></sup><sub></sub></button></div>\r
                <div class="row"><button data-key="End" data-action="gotolineend" data-ctrl-action="gotoend"><span>End</span><sup></sup><sub></sub></button></div>\r
            </div>\r
        </div>\r
        <div class="row">\r
            <div class="col">\r
                <button data-key="Shift" data-action="shift" class="doubleWidth"><span>Shift</span><sub></sub><sup></sup></button>\r
                <button data-key="Ctrl" data-action="ctrl" class="doubleWidth"><span>Ctrl</span><sub></sub><sup></sup></button>\r
            </div>\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="Z" data-action="insertCharacter" data-ctrl-action="undo"><span>~</span><sup>&lt;</sup><sub>\u0626</sub></button>\r
                    <button data-key="X" data-action="insertCharacter" data-ctrl-action="vCut"><span>\xA0\u0652\xA0</span><sup>&gt;</sup><sub>\u0621</sub></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="Alt" data-action="alt" class="doubleWidth"><span>Alt</span><sub></sub><sup></sup></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="C" data-action="insertCharacter" data-ctrl-action="vCopy"><span>}</span><sup>\xAB</sup><sub>\u0624</sub></button>\r
                    <button data-key="V" data-action="insertCharacter" data-ctrl-action="vPaste"><span>{</span><sup>\xBB</sup><sub>\u0631</sub></button>\r
                    <button data-action="insertCharacter"><span>\u0644</span><sup>_</sup><sub>\u0644</sub></button>\r
                    <button data-action="insertCharacter"><span>\u0622</span><sup>~</sup><sub>\u0649</sub></button>\r
                    <button data-action="insertCharacter"><span>\u2019</span><sup>#</sup><sub>\u0629</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>,</span><sup>;</sup><sub>\u0648</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>.</span><sup></sup><sub>\u0632</sub></button>\r
                    <button data-action="insertCharacter" class="cornerAlign"><span>\u061F</span><sup></sup><sub>\u0638</sub></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="switchLayout" data-action="switchLayout" class="doubleWidth"><span>ar</span><sup></sup><sub></sub></button>\r
                    <button data-key="Space" data-action="space" class="quadrupleWidth"><span>____</span><sup></sup><sub></sub></button>\r
                    <button data-key="AltGr" data-action="altgr" class="doubleWidth altgr"><span>Alt Gr</span><sup></sup><sub></sub></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="PageUp" data-action="gotopageup" data-shift-action="selectpageup" class="cornerAlign"><span>&uarr;</span><sub></sub><sup>pg</sup></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="Left" data-action="gotoleft" data-shift-action="selectleft" data-ctrl-shift-action="selectwordleft" data-alt-shift-action="selecttolinestart"><span>&larr;</span><sub></sub><sup></sup></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <button data-key="Up" data-action="golineup" data-shift-action="selectup" data-ctrl-action="scrollup" data-alt-action="movelinesup" data-alt-shift-action="copylinesup"><span>&uarr;</span><sub></sub><sup></sup></button>\r
                <button data-key="Down" data-action="golinedown" data-shift-action="selectdown" data-ctrl-action="scrolldown" data-alt-action="movelinesdown" data-alt-shift-action="copylinesdown"><span>&darr;</span><sub></sub><sup></sup></button>\r
            </div>\r
            <div class="col">\r
                <div class="row">\r
                    <button data-key="PageDown" data-action="gotopagedown" data-shift-action="selectpagedown" class="cornerAlign"><span>&darr;</span><sub></sub><sup>pg</sup></button>\r
                </div>\r
                <div class="row">\r
                    <button data-key="Right" data-action="gotoright" data-shift-action="selectright" data-ctrl-shift-action="selectwordright" data-alt-shift-action="selecttolineend"><span>&rarr;</span><sub></sub><sup></sup></button>\r
                </div>\r
            </div>\r
            <div class="col">\r
                <div class="row"><button data-key="Ins" data-action="overwrite"><span>Ins</span><sup></sup><sub></sub></button></div>\r
                <div class="row"><button data-key="Del" data-action="del" data-ctrl-action="removewordright" data-alt-action="removetolineend"><span>Del</span><sup></sup><sub></sub></button></div>\r
            </div>\r
        </div>\r
    </div>		\r
</div>`}}]);
